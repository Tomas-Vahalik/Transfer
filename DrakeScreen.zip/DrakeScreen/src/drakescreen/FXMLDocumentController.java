/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drakescreen;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author HP
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    private Button button;
    @FXML
    private Rectangle endRec;
    
    private final int recSize = 100;
    private final int buttonX = 77;
    private final int buttonY = 83;
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    @FXML
    private void handleButtonClick(MouseEvent event) {
        
            button.setLayoutX(event.getSceneX());
            button.setLayoutY(event.getSceneY());
       
    }
    @FXML
    private void handleRelease(MouseEvent event) {
        
        
        Bounds recBounds = endRec.localToScene(endRec.getBoundsInLocal());
        Bounds butBounds = button.localToScene(button.getBoundsInLocal());
       
        if(recBounds.contains(butBounds)){
             Stage stage = (Stage) button.getScene().getWindow();
             stage.close();
        }
        //System.out.println(recX + " " + recY);
        button.setLayoutX(390);
        button.setLayoutY(550);
        
                   
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
         
    }    
    
}
