/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.view;

import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TroopInfo;
import java.util.ArrayList;
import java.util.List;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;

/**
 *
 * @author HP
 */
public class CapturedView extends VBox{
    private PlayingSide side;
    private Label label;
    private TextArea area;
    private List<TroopInfo> infos = new ArrayList();

    public CapturedView(PlayingSide side) {
        this.side = side;
        if(side == PlayingSide.BLUE){
            label = new Label("Captured blue:");
        }
        else{
            label = new Label("Captured orange:");
        }
        area = new TextArea();
        area.setEditable(false);
        this.getChildren().add(label);
        this.getChildren().add(area);
        this.setPadding(new Insets(5));
        this.setMaxWidth(250);
    }
    public void setInfos(List<TroopInfo> i){
        infos = i;
    }
    public void update(){
        area.setText("");
        for(TroopInfo i : infos){
            area.setText(area.getText() + "\n" + i.name());
        }
    }
    
    
       
}
