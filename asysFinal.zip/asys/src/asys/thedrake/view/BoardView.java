package asys.thedrake.view;

import java.util.List;

import asys.thedrake.game.GameState;
import asys.thedrake.game.Move;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TilePosition;
import asys.thedrake.game.TroopInfo;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class BoardView extends GridPane implements GameViewContext {

    private GameState state;
    private StackView blueStackView;
    private StackView orangeStackView;
    private boolean blueStackSelected = false;
    private boolean orangeStackSelected = false;
    private CapturedView blueCaptured = new CapturedView(PlayingSide.BLUE);
    private CapturedView orangeCaptured = new CapturedView(PlayingSide.ORANGE);

    public CapturedView getBlueCaptured() {
        return blueCaptured;
    }

    public CapturedView getOrangeCaptured() {
        return orangeCaptured;
    }

    public BoardView() {
        this.setVgap(5);
        this.setHgap(5);
        //this.setPadding(new Insets(5,0,5,200));
        this.setBorder(new Border(
			new BorderStroke(
					Color.BLACK, 
					BorderStrokeStyle.SOLID, 
					null, 
					new BorderWidths(2))));
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                int i = x;
                int j = 3 - y;
                this.add(new TileView(new TilePosition(i, j), this), x, y);
            }
        }
    }

    public void select(PlayingSide side) {
        if (side == PlayingSide.BLUE) {
            blueStackSelected = true;
            orangeStackSelected = false;
        } else {
            blueStackSelected = false;
            orangeStackSelected = true;
        }
    }

    public void deselect() {
        blueStackSelected = false;
        orangeStackSelected = false;
    }

    public TileView tileViewAt(TilePosition pos) {
        //protoze grid ma jiny cislovani
        int index = (3 - pos.j) * 4 + pos.i;

        return (TileView) getChildren().get(index);
    }

    public void setGameState(GameState state) {
        this.state = state;
    }

    public void setBlueStackView(StackView blueStackView) {
        this.blueStackView = blueStackView;
    }

    public void setOrangeStackView(StackView orangeStackView) {
        this.orangeStackView = orangeStackView;
    }

    public GameState getState() {
        return state;
    }

    public void update() {
        if (blueStackSelected) {
            blueStackView.update();

        }
        if (orangeStackSelected) {
            orangeStackView.update();
        }

        for (Node n : this.getChildren()) {
            TileView view = (TileView) n;
            view.unselect();
            view.clearMove();
            view.setTile(state.board().tileAt(view.position()));
            view.update();
        }

    }

    public StackView getBlueStackView() {
        return blueStackView;
    }

    public StackView getOrangeStackView() {
        return orangeStackView;
    }

    @Override
    public void clearSelection() {
        clearAllMoves();
        for (Node n : this.getChildren()) {
            TileView view = (TileView) n;
            view.unselect();
        }
    }

    @Override
    public void setMoves(TilePosition position) {
        clearAllMoves();
        List<Move> moves = state.boardMoves(position);

        for (Move move : moves) {
            tileViewAt(move.target()).setMove(move);
        }
    }

    @Override
    public void setStackMoves(PlayingSide side) {
        clearAllMoves();
        if (side != state.sideOnTurn()) {
            return;
        }
        List<Move> moves = state.stackMoves();
        for (Move move : moves) {
            tileViewAt(move.target()).setMove(move);
        }

    }

    public void clearAllMoves() {
        for (Node n : this.getChildren()) {
            TileView view = (TileView) n;
            view.clearMove();
        }
    }

    @Override
    public void executeMove(Move move) {
        GameState newState = move.resultState();
        setGameState(newState);
        if (state.isVictory()) {
            //vycisteni
            this.getChildren().clear();
            String winSide;
            Color winColor;
            //kdo vyhral
            if (state.sideOnTurn() == PlayingSide.BLUE) {
                winSide = "Orange";
                winColor = Color.ORANGE;
            } else {
                winSide = "Blue";
                winColor = Color.BLUE;
            }
            //komponenty
            Label winLabel = new Label(winSide + " wins!!!!!");
            winLabel.setFont(javafx.scene.text.Font.font(26));
            winLabel.setTextFill(winColor);
            winLabel.setTextAlignment(TextAlignment.CENTER);
            
            winLabel.setPadding(new Insets(70, 0, 0, 0));
            BoardView bv = this;
            
            Button homeButton = new Button("Home page");
            
            homeButton.setOnAction(new EventHandler<ActionEvent>() {
                //Zobrazeni homepage
                @Override
                public void handle(ActionEvent e) {
                    try {
                        Parent root;
                        Stage stage = (Stage) bv.getScene().getWindow();
                        root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
                        Scene scene = new Scene(root);

                        stage.setScene(scene);
                        stage.show();
                    } catch (IOException ex) {
                        Logger.getLogger(BoardView.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            Label helpLabel = new Label(" ");
            helpLabel.setMinWidth(140);
            this.add(helpLabel, 0, 0);
            this.add(winLabel, 1, 0);
            this.add(homeButton,1, 1);
            
            return;
        }

        List<TroopInfo> capBlue = state.board().captured().troops(PlayingSide.BLUE);
        List<TroopInfo> capOrange = state.board().captured().troops(PlayingSide.ORANGE);
        blueCaptured.setInfos(capBlue);
        blueCaptured.update();
        orangeCaptured.setInfos(capOrange);
        orangeCaptured.update();

        System.out.println(newState);

        update();
        deselect();
    }
}
