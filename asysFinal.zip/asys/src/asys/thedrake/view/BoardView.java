package asys.thedrake.view;

import java.util.List;

import asys.thedrake.game.GameState;
import asys.thedrake.game.Move;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TilePosition;
import asys.thedrake.game.TroopInfo;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;

public class BoardView extends GridPane implements GameViewContext {
	
	private GameState state;
	private StackView blueStackView;
	private StackView orangeStackView;
        private boolean blueStackSelected = false;
        private boolean orangeStackSelected = false;
        private CapturedView blueCaptured = new CapturedView(PlayingSide.BLUE);
        private CapturedView orangeCaptured = new CapturedView(PlayingSide.ORANGE);

    public CapturedView getBlueCaptured() {
        return blueCaptured;
    }

    public CapturedView getOrangeCaptured() {
        return orangeCaptured;
    }
        
	public BoardView() {
    		this.setVgap(5);
		this.setHgap(5);
		//this.setPadding(new Insets(5,0,5,200));
		
		for(int y = 0; y < 4; y++) {
			for(int x = 0; x < 4; x++) {
				int i = x;
				int j = 3 - y;
				this.add(new TileView(new TilePosition(i, j), this), x, y);
			}	
		}
	}
	public void select(PlayingSide side){
            if(side == PlayingSide.BLUE){
                blueStackSelected = true;
                orangeStackSelected = false;
            }
            else{
                 blueStackSelected = false;
                orangeStackSelected = true;
            }
        }
	
        public void deselect(){
             blueStackSelected = false;
            orangeStackSelected = false;
        }
	public TileView tileViewAt(TilePosition pos) {
                //protoze grid ma jiny cislovani
		int index = (3-pos.j)*4 + pos.i; 
		
		return (TileView)getChildren().get(index);
	}
	
	public void setGameState(GameState state) {
		this.state = state;
	}

    public void setBlueStackView(StackView blueStackView) {
        this.blueStackView = blueStackView;
    }

     public void setOrangeStackView(StackView orangeStackView) {
        this.orangeStackView = orangeStackView;
     }
      
	public GameState getState(){
            return state;
        }
	public void update() {
             if(blueStackSelected){
                 blueStackView.update();
               
             }
             if(orangeStackSelected) orangeStackView.update(); 
                
		for(Node n : this.getChildren()) {
			TileView view = (TileView)n;
			view.unselect();
			view.clearMove();
			view.setTile(state.board().tileAt(view.position()));			
			view.update();
		}
               
	}

    public StackView getBlueStackView() {
        return blueStackView;
    }

    public StackView getOrangeStackView() {
        return orangeStackView;
    }

	@Override
	public void clearSelection() {
		clearAllMoves();
		for(Node n : this.getChildren()) {
			TileView view = (TileView)n;
			view.unselect();
		}
	}
	
	@Override
	public void setMoves(TilePosition position) {
		clearAllMoves();
		List<Move> moves = state.boardMoves(position);
		
		for(Move move : moves) {
			tileViewAt(move.target()).setMove(move);
		}
	}
        
        @Override
	public void setStackMoves(PlayingSide side){
                clearAllMoves();
                if(side != state.sideOnTurn()) return;
		List<Move> moves = state.stackMoves();
		for(Move move : moves) {
			tileViewAt(move.target()).setMove(move);
		}
               
        }
	public void clearAllMoves() {
		for(Node n : this.getChildren()) {
			TileView view = (TileView)n;
			view.clearMove();
		}		
	}
	
	@Override
	public void executeMove(Move move) {
		GameState newState = move.resultState();
		setGameState(newState);
                if(state.isVictory()){
                    System.exit(0);
                }
                
                List<TroopInfo> capBlue = state.board().captured().troops(PlayingSide.BLUE);
                List<TroopInfo> capOrange = state.board().captured().troops(PlayingSide.ORANGE);
                blueCaptured.setInfos(capBlue);
                blueCaptured.update();
                orangeCaptured.setInfos(capOrange);
                orangeCaptured.update();
                
                System.out.println(newState);
               /* System.out.println("CBlue:");
                for(TroopInfo t : state.board().captured().troops(PlayingSide.BLUE)){
                    System.out.println(t.name());
                }
                
                System.out.println("COrange:");
                for(TroopInfo t : state.board().captured().troops(PlayingSide.ORANGE)){
                    System.out.println(t.name());
                }*/
		update();
                deselect();
	}
}
