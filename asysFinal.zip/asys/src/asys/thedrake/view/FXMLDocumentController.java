/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.view;

import asys.thedrake.game.GameState;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TroopStacks;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author HP
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Rectangle twoPRec;
    @FXML
    private Button button;
    @FXML
    private Rectangle endRec;
    
    private final int recSize = 100;
    private final int buttonX = 77;
    private final int buttonY = 83;
    
        
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    @FXML
    private void handleButtonClick(MouseEvent event) {
        
            button.setLayoutX(event.getSceneX());
            button.setLayoutY(event.getSceneY());
       
    }
    @FXML
    private void handleRelease(MouseEvent event) {
        
        
        Bounds recBounds = endRec.localToScene(endRec.getBoundsInLocal());
        Bounds  twoBounds = twoPRec.localToScene(twoPRec.getBoundsInLocal());
        Bounds butBounds = button.localToScene(button.getBoundsInLocal());
        Stage stage = (Stage) button.getScene().getWindow();
        if(recBounds.contains(butBounds)){
             
             stage.close();
        }
         if(twoBounds.contains(butBounds)){
            TheDrakeApplication app= new TheDrakeApplication();
            GameState state = app.getState();
            BoardView bv = new BoardView();
            bv.setGameState(state);
            
            
                TroopStacks s = app.createStacks();
                bv.setBlueStackView(new StackView(s, 7, bv, PlayingSide.BLUE));
                bv.setOrangeStackView(new StackView(s, 7, bv, PlayingSide.ORANGE));
                
                VBox blueCap = bv.getBlueCaptured();
                VBox orangeCap = bv.getOrangeCaptured();
                BorderPane.setAlignment(bv, Pos.CENTER);
                BorderPane.setAlignment(bv.getBlueStackView(), Pos.BOTTOM_CENTER);
                BorderPane.setAlignment(bv.getOrangeStackView(), Pos.TOP_CENTER);
                BorderPane root = new BorderPane();
                root.setTop(bv.getOrangeStackView());
                root.setLeft(blueCap);
                root.setRight(orangeCap);
                root.setCenter(bv);
                root.setBottom(bv.getBlueStackView());
            
            
            
            
           
           Scene scene = new Scene(root);
	   stage.setScene(scene);
	   stage.setTitle("The Drake");
           bv.update();
           stage.show();  
        }
        //System.out.println(recX + " " + recY);
        /*button.setLayoutX(390);
        button.setLayoutY(550);*/
        button.setLayoutX(stage.getWidth() / 2);
        button.setLayoutY(stage.getY() + stage.getHeight() - 100);
        
                   
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
         
    }    
    
}
