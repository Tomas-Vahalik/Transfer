/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.view;

import asys.thedrake.game.EmptyTile;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TilePosition;
import asys.thedrake.game.Troop;
import asys.thedrake.game.TroopInfo;
import asys.thedrake.game.TroopTile;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.Pane;
import static javafx.scene.layout.Region.USE_PREF_SIZE;
import javafx.scene.paint.Color;

/**
 *
 * @author HP
 */
public class TroopView extends Pane{

	public static final Background EMPTY_BG = new Background(
			new BackgroundFill(new Color(0.9, 0.9, 0.9, 1), null, null));
	private final TroopImageSet set;
	public final Border selectBorder = new Border(
			new BorderStroke(
					Color.BLACK, 
					BorderStrokeStyle.SOLID, 
					null, 
					new BorderWidths(4)));
	
	
	private BoardView context;
        private final TileBackgrounds backgrounds;
        //private ImageView troopImage;
        private PlayingSide side;
        private boolean isTop = false;
	public TroopView(BoardView context, TroopInfo troop, PlayingSide side) {
		set = new TroopImageSet(troop.name());
                this.side = side;
                this.backgrounds = new TileBackgrounds();
                 //troopImage = new ImageView(set.get(side, TroopFace.FRONT));                          
		//this.getChildren().add(troopImage);
                this.setBackground(backgrounds.get(new EmptyTile(new TilePosition(-1,-1))));
                this.context = context;

		this.setPrefSize(100, 100);
		this.setMinSize(USE_PREF_SIZE, USE_PREF_SIZE);
		this.setMaxSize(USE_PREF_SIZE, USE_PREF_SIZE);
		this.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				onClicked(event);
			}			
		});
                
	}
	public void setBg(Troop t){
           this.setBackground(backgrounds.get(new TroopTile(new TilePosition(0,0), t)));
        }
        public void setEmptyBg(){
           this.setBackground(backgrounds.EMPTY_BG);
        }
	
	public void select() {
                
		context.setStackMoves(side);
                context.select(side);
	}
	
	public void unselect() {
		this.setBorder(null);
	}
        public void setTop(boolean t){
            isTop = t;
        }
	private void onClicked(MouseEvent event) {
		if(isTop)
		select();
		
			
	}
}


