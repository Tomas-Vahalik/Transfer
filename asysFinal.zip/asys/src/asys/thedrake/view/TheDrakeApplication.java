/*package asys.thedrake.view;

import asys.thedrake.game.BasicTroopStacks;
import asys.thedrake.game.Board;
import asys.thedrake.game.BothLeadersPlaced;
import asys.thedrake.game.CapturedTroops;
import asys.thedrake.game.GameState;
import asys.thedrake.game.MiddleGameState;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.StandardDrakeSetup;
import asys.thedrake.game.TilePosition;
import asys.thedrake.game.Troop;
import asys.thedrake.game.TroopFace;
import asys.thedrake.game.TroopTile;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TheDrakeApplication extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		BoardView boardView = new BoardView();
		Scene scene = new Scene(boardView);
		stage.setScene(scene);
		stage.setTitle("The Drake");
		
		GameState state = createTestGame();
		boardView.setGameState(state);
		boardView.update();
		stage.show();
	}

	private Board createTestBoard() {
		StandardDrakeSetup setup = new StandardDrakeSetup();
		Board board = new Board(
				4, 
				new CapturedTroops(),
				new TroopTile(new TilePosition("a1"), new Troop(setup.MONK, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("b1"), new Troop(setup.DRAKE, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("a2"), new Troop(setup.SPEARMAN, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("c2"), new Troop(setup.CLUBMAN, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("a4"), new Troop(setup.ARCHER, PlayingSide.ORANGE, TroopFace.BACK)),
				new TroopTile(new TilePosition("b4"), new Troop(setup.DRAKE, PlayingSide.ORANGE, TroopFace.BACK)),
				new TroopTile(new TilePosition("c3"), new Troop(setup.SWORDSMAN, PlayingSide.ORANGE)));
		return board;
	}
	
	private GameState createTestGame() {
		Board board = createTestBoard();
		StandardDrakeSetup setup = new StandardDrakeSetup();
		return new MiddleGameState(
				board, 
					new BasicTroopStacks(setup.CLUBMAN), 
					new BothLeadersPlaced(new TilePosition("b1"), new TilePosition("b4")), 
					PlayingSide.BLUE);
	}
}*/



package asys.thedrake.view;

import asys.thedrake.game.BasicTroopStacks;
import asys.thedrake.game.Board;
import asys.thedrake.game.CapturedTroops;
import asys.thedrake.game.GameState;
import asys.thedrake.game.PlacingLeadersGameState;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.StandardDrakeSetup;
import asys.thedrake.game.TilePosition;
import asys.thedrake.game.Troop;
import asys.thedrake.game.TroopFace;
import asys.thedrake.game.TroopStacks;
import asys.thedrake.game.TroopTile;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TheDrakeApplication /*extends Application */{
        private GameState state = createTestGame();
	/*public static void main(String[] args) {
		launch(args);
	}*/
        public GameState getState(){
            return state;
        }
	/*@Override
	public void start(Stage stage) throws Exception {
		BoardView boardView = new BoardView();
                TroopStacks s = createStacks();
                boardView.setBlueStackView(new StackView(s, 7, boardView, PlayingSide.BLUE));
                boardView.setOrangeStackView(new StackView(s, 7, boardView, PlayingSide.ORANGE));
                
                VBox blueCap = boardView.getBlueCaptured();
                VBox orangeCap = boardView.getOrangeCaptured();
                BorderPane.setAlignment(boardView, Pos.CENTER);
                BorderPane.setAlignment(boardView.getBlueStackView(), Pos.BOTTOM_CENTER);
                BorderPane.setAlignment(boardView.getOrangeStackView(), Pos.TOP_CENTER);
                BorderPane root = new BorderPane();
                root.setTop(boardView.getOrangeStackView());
                root.setLeft(blueCap);
                root.setRight(orangeCap);
                root.setCenter(boardView);
                root.setBottom(boardView.getBlueStackView());
                
                
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("The Drake");
		
		GameState state = createTestGame();
		boardView.setGameState(state);
		boardView.update();
                
		stage.show();
	}*/

	public Board createTestBoard() {
		StandardDrakeSetup setup = new StandardDrakeSetup();
		Board board = new Board(
				4, 
				new CapturedTroops(),
				new TroopTile(new TilePosition("a1"), new Troop(setup.MONK, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("b1"), new Troop(setup.DRAKE, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("a2"), new Troop(setup.SPEARMAN, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("c2"), new Troop(setup.CLUBMAN, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("a4"), new Troop(setup.ARCHER, PlayingSide.ORANGE, TroopFace.BACK)),
				new TroopTile(new TilePosition("b4"), new Troop(setup.DRAKE, PlayingSide.ORANGE, TroopFace.BACK)),
				new TroopTile(new TilePosition("c3"), new Troop(setup.SWORDSMAN, PlayingSide.ORANGE)));
		return board;
	}
	public TroopStacks createStacks(){
            StandardDrakeSetup setup = new StandardDrakeSetup();
            return new BasicTroopStacks(setup.DRAKE,setup.CLUBMAN,setup.CLUBMAN,setup.MONK,setup.SPEARMAN,setup.SWORDSMAN, setup.ARCHER);
        }
	public GameState createTestGame() {
		Board board = createTestBoard();
		StandardDrakeSetup setup = new StandardDrakeSetup();
                TroopStacks stack = createStacks();
		/*return new MiddleGameState(
                                            board, 
					createStacks(), 
					new BothLeadersPlaced(new TilePosition("b1"), new TilePosition("b4")), 
					PlayingSide.BLUE);*/
                return new PlacingLeadersGameState(createStacks());
					
	}
}
