

package asys.thedrake.view;

import asys.thedrake.game.BasicTroopStacks;
import asys.thedrake.game.Board;
import asys.thedrake.game.CapturedTroops;
import asys.thedrake.game.GameState;
import asys.thedrake.game.PlacingLeadersGameState;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.StandardDrakeSetup;
import asys.thedrake.game.TilePosition;
import asys.thedrake.game.Troop;
import asys.thedrake.game.TroopFace;
import asys.thedrake.game.TroopStacks;
import asys.thedrake.game.TroopTile;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TheDrakeApplication {
        private GameState state = createTestGame();
	
        public GameState getState(){
            return state;
        }
	
	public Board createTestBoard() {
		StandardDrakeSetup setup = new StandardDrakeSetup();
		Board board = new Board(
				4, 
				new CapturedTroops(),
				new TroopTile(new TilePosition("a1"), new Troop(setup.MONK, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("b1"), new Troop(setup.DRAKE, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("a2"), new Troop(setup.SPEARMAN, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("c2"), new Troop(setup.CLUBMAN, PlayingSide.BLUE)),
				new TroopTile(new TilePosition("a4"), new Troop(setup.ARCHER, PlayingSide.ORANGE, TroopFace.BACK)),
				new TroopTile(new TilePosition("b4"), new Troop(setup.DRAKE, PlayingSide.ORANGE, TroopFace.BACK)),
				new TroopTile(new TilePosition("c3"), new Troop(setup.SWORDSMAN, PlayingSide.ORANGE)));
		return board;
	}
	public TroopStacks createStacks(){
            StandardDrakeSetup setup = new StandardDrakeSetup();
            return new BasicTroopStacks(setup.DRAKE,setup.CLUBMAN,setup.CLUBMAN,setup.MONK,setup.SPEARMAN,setup.SWORDSMAN, setup.ARCHER);
        }
	public GameState createTestGame() {
		Board board = createTestBoard();
		StandardDrakeSetup setup = new StandardDrakeSetup();
                TroopStacks stack = createStacks();
		
                return new PlacingLeadersGameState(createStacks());
					
	}
}
