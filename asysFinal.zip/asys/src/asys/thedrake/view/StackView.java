/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.view;

import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.Troop;
import asys.thedrake.game.TroopInfo;
import asys.thedrake.game.TroopStacks;
import java.util.List;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.Border;
import javafx.scene.layout.GridPane;

/**
 *
 * @author HP
 */
public class StackView extends GridPane{
    private TroopStacks stacks;
    private int size;
    int selectIndex = 0;
    private List<TroopInfo> infos;
    private BoardView context;
    private PlayingSide side;
    public StackView(TroopStacks stacks, int size, BoardView context, PlayingSide side){
        this.setVgap(5);
	this.setHgap(5);
        this.stacks = stacks;
        this.side = side;
        infos = stacks.troops(side);        
        this.size = size;
        this.context = context;
        this.setPadding(new Insets(5,0,5,150));
        for(int i = 0; i < size; i++) {
            TroopView v = new TroopView(context,infos.get(i),side);
            if(i == 0) {
                v.setTop(true);
                v.setBorder(v.selectBorder);
            }
            v.setBg(new Troop(infos.get(i), side));
	    this.add(v, i, 0);
                      
				
        }
        
    }   
    public void update(){
        stacks.pop(side);
   
        size--;
        for (Node node : this.getChildren()) {
            if (this.getRowIndex(node) == 0 && this.getColumnIndex(node) == selectIndex) {
                TroopView v = (TroopView) node;
                v.setEmptyBg();
                v.setBorder(Border.EMPTY);
                v.setTop(false);
            }
            if (this.getRowIndex(node) == 0 && this.getColumnIndex(node) == selectIndex + 1) {
                TroopView v = (TroopView) node;
                v.setTop(true);
                v.setBorder(v.selectBorder);
            }

        }
        selectIndex ++;
    }

    
    
}
