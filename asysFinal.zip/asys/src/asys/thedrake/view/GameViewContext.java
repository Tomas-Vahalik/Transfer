package asys.thedrake.view;

import asys.thedrake.game.Move;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TilePosition;

public interface GameViewContext {
	public void clearSelection();
	public void setMoves(TilePosition position); 
        public void setStackMoves(PlayingSide side); 
	public void executeMove(Move move);
}
