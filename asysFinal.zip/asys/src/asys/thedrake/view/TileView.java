package asys.thedrake.view;

import asys.thedrake.game.Move;
import asys.thedrake.game.Tile;
import asys.thedrake.game.TilePosition;
import javafx.event.EventHandler;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class TileView extends Pane {
	private final TilePosition position;
	private final TileBackgrounds backgrounds;
	private final Border selectBorder = new Border(
			new BorderStroke(
					Color.BLACK, 
					BorderStrokeStyle.SOLID, 
					null, 
					new BorderWidths(2)));
	
	private Tile tile;
	private final GameViewContext context;
	private ImageView moveImage;
	private Move move;
	
	public TileView(TilePosition position, GameViewContext context) {
		this.position = position;
		this.backgrounds = new TileBackgrounds();
		this.context = context;
		this.moveImage = new ImageView(getClass().getResource("/assets/move.png").toString());
		
		this.moveImage.setVisible(false);
		this.getChildren().add(moveImage);

		this.setPrefSize(100, 100);
		this.setMinSize(USE_PREF_SIZE, USE_PREF_SIZE);
		this.setMaxSize(USE_PREF_SIZE, USE_PREF_SIZE);
		this.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				onClicked(event);
			}			
		});
	}
	
	public TilePosition position() {
		return position;
	}
	
	public void setTile(Tile tile) {
		this.tile = tile;
	}
	
	public void update() {
		this.setBackground(backgrounds.get(tile));
	}
	
	public void select() {
		this.setBorder(selectBorder);
		context.setMoves(position);
	}
	
	public void unselect() {
		this.setBorder(null);
	}

	public void setMove(Move move) {
		moveImage.setVisible(true);
		this.move = move;
	}
	
	public Move move() {
		return move;	
	}
	
	public void clearMove() {
		moveImage.setVisible(false);
		move = null;
	}
	
	private void onClicked(MouseEvent event) {
		if(this.move != null)
			context.executeMove(move);
		else {
			context.clearSelection();
			if(tile.hasTroop()) { 		
				select();
			}
		}
		
		
	}
}
