package asys.thedrake.media;

import asys.thedrake.game.CapturedTroops;

public interface CapturedTroopsMedia<T> {
	public T putCapturedTroops(CapturedTroops captured);
}
