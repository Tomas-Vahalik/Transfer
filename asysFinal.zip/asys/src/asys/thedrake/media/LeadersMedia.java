package asys.thedrake.media;

import asys.thedrake.game.BothLeadersPlaced;
import asys.thedrake.game.NoLeadersPlaced;
import asys.thedrake.game.OneLeaderPlaced;

public interface LeadersMedia<T> {
	public T putNoLeadersPlaced(NoLeadersPlaced leaders);
	public T putOneLeaderPlaced(OneLeaderPlaced leaders);
	public T putBothLeadersPlaced(BothLeadersPlaced leaders);
}
