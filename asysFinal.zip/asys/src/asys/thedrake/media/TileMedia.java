package asys.thedrake.media;

import asys.thedrake.game.EmptyTile;
import asys.thedrake.game.TroopTile;

public interface TileMedia<T> {
	public T putTroopTile(TroopTile tile);	
	public T putEmptyTile(EmptyTile tile);
}
