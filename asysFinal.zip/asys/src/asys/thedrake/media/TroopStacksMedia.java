package asys.thedrake.media;

import asys.thedrake.game.BasicTroopStacks;

public interface TroopStacksMedia<T> {
	public T putBasicTroopStacks(BasicTroopStacks stacks);
}
