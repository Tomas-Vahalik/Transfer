/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.media.plaintext;

import asys.thedrake.game.CapturedTroops;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TroopInfo;
import asys.thedrake.media.CapturedTroopsMedia;
import asys.thedrake.media.PrintMedia;
import java.io.OutputStream;
import java.io.PrintWriter;

/**
 *
 * @author asys
 */
public class CapturedTroopsPlainTextMedia extends PrintMedia implements CapturedTroopsMedia<Void> {

    public CapturedTroopsPlainTextMedia(OutputStream stream) {
        super(stream);
    }

    @Override
    public Void putCapturedTroops(CapturedTroops captured) {
        PrintWriter w = writer();
        
        w.print("Captured BLUE: " + captured.troops(PlayingSide.BLUE).size());
        for (TroopInfo t : captured.troops(PlayingSide.BLUE)) {
            w.println();
            w.print(t.name());
            w.flush();
        }
        w.println();
        w.print("Captured ORANGE: " + captured.troops(PlayingSide.ORANGE).size());
        w.flush();
        for (TroopInfo t : captured.troops(PlayingSide.ORANGE)) {
            w.println();
            w.print(t.name());
            w.flush();
        }
        return null;
    }
    
    
}
