/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.media.plaintext;

import asys.thedrake.game.BothLeadersPlaced;
import asys.thedrake.game.NoLeadersPlaced;
import asys.thedrake.game.OneLeaderPlaced;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.media.LeadersMedia;
import asys.thedrake.media.PrintMedia;
import java.io.OutputStream;
import java.io.PrintWriter;

/**
 *
 * @author asys
 */
public class LeadersPlainTextMedia  extends PrintMedia implements LeadersMedia<Void> {

    LeadersPlainTextMedia(OutputStream stream) {
        super(stream);
    }

    @Override
    public Void putNoLeadersPlaced(NoLeadersPlaced leaders) {
        PrintWriter w = writer();
        w.println("NL");
        return null;
    }

    @Override
    public Void putOneLeaderPlaced(OneLeaderPlaced leaders) {
        PrintWriter w = writer();
        String posString = "";
        if (leaders.isPlaced(PlayingSide.BLUE) == true)
            posString = leaders.position(PlayingSide.BLUE).toString();
        else
            posString = "X " + leaders.position(PlayingSide.ORANGE);
        w.println("OL " + posString);
        return null;
    }

    @Override
    public Void putBothLeadersPlaced(BothLeadersPlaced leaders) {
        PrintWriter w = writer();
        w.println("BL " + leaders.position(PlayingSide.BLUE) + " " + leaders.position(PlayingSide.ORANGE));
        return null;
    }
    
}
