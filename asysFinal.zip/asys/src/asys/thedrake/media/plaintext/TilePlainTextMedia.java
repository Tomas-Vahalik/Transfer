/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.media.plaintext;

import asys.thedrake.game.EmptyTile;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TroopFace;
import asys.thedrake.game.TroopTile;
import asys.thedrake.media.PrintMedia;
import asys.thedrake.media.TileMedia;
import java.io.OutputStream;
import java.io.PrintWriter;

/**
 *
 * @author asys
 */
public class TilePlainTextMedia extends PrintMedia implements TileMedia<Void> {

    TilePlainTextMedia(OutputStream stream) {
        super(stream);
    }

    @Override
    public Void putTroopTile(TroopTile tile) {
        PrintWriter w = writer();
        String sideString = (tile.troop().side() == PlayingSide.BLUE) ? "BLUE" : "ORANGE";
        String faceString = (tile.troop().face() == TroopFace.FRONT) ? "FRONT" : "BACK";
        w.print(tile.troop().info().name() + " " + sideString + " " + faceString);
        w.flush();
        return null;
    }

    @Override
    public Void putEmptyTile(EmptyTile tile) {
        PrintWriter w = writer();
        w.print("empty");
        w.flush();
        return null;
    }
    
}
