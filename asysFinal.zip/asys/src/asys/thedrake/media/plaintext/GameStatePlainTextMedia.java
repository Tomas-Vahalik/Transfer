/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.media.plaintext;

import asys.thedrake.game.MiddleGameState;
import asys.thedrake.game.PlacingGuardsGameState;
import asys.thedrake.game.PlacingLeadersGameState;
import asys.thedrake.game.VictoryGameState;
import asys.thedrake.media.GameStateMedia;
import asys.thedrake.media.PrintMedia;
import java.io.OutputStream;
import java.io.PrintWriter;

/**
 *
 * @author asys
 */
public class GameStatePlainTextMedia extends PrintMedia implements GameStateMedia<Void> {

    private final LeadersPlainTextMedia leadersMedia;
    private final TroopStacksPlainTextMedia troopStacksMedia;
    private final BoardPlainTextMedia boardMedia;
    
    public GameStatePlainTextMedia(OutputStream stream) {
        super(stream);
        this.leadersMedia = new LeadersPlainTextMedia(stream);
        this.troopStacksMedia = new TroopStacksPlainTextMedia(stream);
        this.boardMedia = new BoardPlainTextMedia(stream);
    }

    @Override
    public Void putPlacingLeadersGameState(PlacingLeadersGameState state) {
        PrintWriter w = writer();
        w.println("LEADERS");
        w.println("0");
        w.println(state.sideOnTurn());
        
        state.troopStacks().putToMedia(troopStacksMedia);
        state.leaders().putToMedia(leadersMedia);
        state.board().putToMedia(boardMedia);
        
        return null;
    }

    @Override
    public Void putPlacingGuardsGameState(PlacingGuardsGameState state) {
        PrintWriter w = writer();
        w.println("GUARDS");
        w.println(state.guardsCount());
        w.println(state.sideOnTurn());
        
        state.troopStacks().putToMedia(troopStacksMedia);
        state.leaders().putToMedia(leadersMedia);
        state.board().putToMedia(boardMedia);
        
        return null;
    }

    @Override
    public Void putMiddleGameState(MiddleGameState state) {
        PrintWriter w = writer();
        w.println("MIDDLE");
        w.println("4");
        w.println(state.sideOnTurn());
        
        state.troopStacks().putToMedia(troopStacksMedia);
        state.leaders().putToMedia(leadersMedia);
        state.board().putToMedia(boardMedia);
        
        return null;
    }

    @Override
    public Void putFinishedGameState(VictoryGameState state) {
        PrintWriter w = writer();
        w.println("VICTORY");
        w.println("4");
        w.println(state.sideOnTurn());
        
        state.troopStacks().putToMedia(troopStacksMedia);
        state.leaders().putToMedia(leadersMedia);
        state.board().putToMedia(boardMedia);
        
        return null;
    }
    
}
