/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asys.thedrake.media.plaintext;

import asys.thedrake.game.BasicTroopStacks;
import asys.thedrake.game.PlayingSide;
import asys.thedrake.game.TroopInfo;
import asys.thedrake.media.PrintMedia;
import asys.thedrake.media.TroopStacksMedia;
import java.io.OutputStream;
import java.io.PrintWriter;

/**
 *
 * @author asys
 */
public class TroopStacksPlainTextMedia extends PrintMedia implements TroopStacksMedia<Void> {

    TroopStacksPlainTextMedia(OutputStream stream) {
        super(stream);
    }

    @Override
    public Void putBasicTroopStacks(BasicTroopStacks stacks) {
        PrintWriter w = writer();
        
        w.print("BLUE stack:");
        for (TroopInfo t : stacks.troops(PlayingSide.BLUE)) {
            w.print(" " + t.name());
        }
        w.println();
        
        w.print("ORANGE stack:");
        for (TroopInfo t : stacks.troops(PlayingSide.ORANGE)) {
            w.print(" " + t.name());
        }
        w.println();
        
        return null;
    }
    
}
