
package asys.thedrake.media;

import asys.thedrake.game.MiddleGameState;
import asys.thedrake.game.PlacingGuardsGameState;
import asys.thedrake.game.PlacingLeadersGameState;
import asys.thedrake.game.VictoryGameState;

public interface GameStateMedia<T> {
	public T putPlacingLeadersGameState(PlacingLeadersGameState state);
	public T putPlacingGuardsGameState(PlacingGuardsGameState state);
	public T putMiddleGameState(MiddleGameState state);
	public T putFinishedGameState(VictoryGameState state);
}

