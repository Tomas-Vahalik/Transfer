package asys.thedrake.media;

import asys.thedrake.game.Board;

public interface BoardMedia<T> {
	public T putBoard(Board board);
}
