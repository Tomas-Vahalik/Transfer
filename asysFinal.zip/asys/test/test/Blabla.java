/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import asys.thedrake.game.BasicTroopStacks;
import asys.thedrake.game.PlacingLeadersGameState;
import asys.thedrake.game.StandardDrakeSetup;
import asys.thedrake.media.plaintext.GameStatePlainTextMedia;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class Blabla {
    private static PlacingLeadersGameState createTestState() {
		StandardDrakeSetup setup = new StandardDrakeSetup();
		
		return new PlacingLeadersGameState(
				new BasicTroopStacks(
						setup.DRAKE, 
						setup.CLUBMAN,
						setup.CLUBMAN,
						setup.MONK, 
						setup.SPEARMAN,
						setup.SWORDSMAN,
						setup.ARCHER));
	}
    public static void main(String[] args) {
        ByteArrayOutputStream baos01 = new ByteArrayOutputStream();
		GameStatePlainTextMedia media01 = new GameStatePlainTextMedia(baos01);		
		PlacingLeadersGameState state01 = createTestState();
		state01.putToMedia(media01);
                
        try {
            baos01.close();
        } catch (IOException ex) {
            Logger.getLogger(Blabla.class.getName()).log(Level.SEVERE, null, ex);
        }
		String expected01 = 
				"LEADERS\r\n" +
				"0\r\n" +
				"BLUE\r\n" + 
				"BLUE stack: Drake Clubman Clubman Monk Spearman Swordsman Archer\r\n" +
				"ORANGE stack: Drake Clubman Clubman Monk Spearman Swordsman Archer\r\n" +
				"NL\r\n" +
				"4\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"empty\r\n" +
				"Captured BLUE: 0\r\n" +
				"Captured ORANGE: 0";
                
                 try {
            Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream("soubor1.txt"), "UTF8"));
            out.write(expected01);
            out.close();
        } catch (UnsupportedEncodingException e) {
        } catch (IOException e) {
        }
                  try {
            Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream("soubor2.txt"), "UTF8"));
            out.write(baos01.toString());
            out.close();
        } catch (UnsupportedEncodingException e) {
        } catch (IOException e) {
        }
    }
    
   
}
